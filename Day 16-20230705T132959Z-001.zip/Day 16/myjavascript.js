function stringLength() {
    var name = $("#firstname").val();
    alert("User name is :" + name.length);
}